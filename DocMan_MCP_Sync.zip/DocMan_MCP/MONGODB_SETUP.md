# DocMan_MCP - MongoDB Setup Instructions

## Database Configuration

This project has been configured to use MongoDB locally instead of PostgreSQL. Here are the setup instructions:

### Prerequisites

1. **Install MongoDB locally:**
   - **Ubuntu/Debian**: 
     ```bash
     sudo apt-get install mongodb
     sudo systemctl start mongodb
     sudo systemctl enable mongodb
     ```
   - **macOS**: 
     ```bash
     brew install mongodb-community
     brew services start mongodb-community
     ```
   - **Windows**: Download from [MongoDB official website](https://www.mongodb.com/try/download/community)

2. **Verify MongoDB is running:**
   ```bash
   mongo --eval "db.adminCommand('ismaster')"
   ```

### Environment Configuration

The `.env` file is already configured for MongoDB:
```env
MONGODB_URL=mongodb://localhost:27017
DATABASE_NAME=docman_db
SECRET_KEY=your-secret-key-here
DEBUG=True
UPLOAD_FOLDER=src/uploads
```

### Dependencies

The project uses these MongoDB-related packages:
- `pymongo`: Official MongoDB driver

### Database Models

The models have been updated to use simple Python classes with `pymongo` for direct interaction:
- `User`: User management with ObjectId
- `Document`: Document storage with file references
- `Project`: Project organization with document associations

### API Changes

All API endpoints now use:
- ObjectId instead of integer IDs
- Synchronous database operations
- MongoDB queries instead of SQL

### Running the Application

1. **Install dependencies:**
   ```bash
   pip install -r src/requirements.txt
   ```

2. **Start MongoDB** (if not already running)

3. **Run the application:**
   ```bash
   uvicorn main:app --reload --host 0.0.0.0 --port 8000
   ```

4. **Access the API:**
   - API Documentation: http://localhost:8000/docs
   - Health Check: http://localhost:8000/

### Summary Agent Implementation

The `Summary_agent.py` file contains placeholder methods that you need to implement:

```python
class SummaryAgent:
    def generate_summary(self, text_content: str) -> str:
        # Implement your summarization logic here
        pass
    
    def generate_project_summary(self, combined_summaries: str) -> str:
        # Implement your project summary logic here
        pass
```

### Testing

You can test the API endpoints using the interactive documentation at `/docs` or with curl:

```bash
# Create a user
curl -X POST "http://localhost:8000/api/v1/users/" \
     -H "Content-Type: application/json" \
     -d '{"username": "testuser", "email": "test@example.com", "password": "testpass"}'

# Upload a document
curl -X POST "http://localhost:8000/api/v1/documents/upload/" \
     -F "file=@your_document.pdf"
```

The project is now fully configured for MongoDB and ready for use!

