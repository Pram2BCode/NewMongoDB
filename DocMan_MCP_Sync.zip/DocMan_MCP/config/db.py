from pymongo import MongoClient
import os
from dotenv import load_dotenv

load_dotenv("src/utils/.env")

# MongoDB configuration
MONGODB_URL = os.getenv("MONGODB_URL", "mongodb://localhost:27017/")
DATABASE_NAME = os.getenv("DATABASE_NAME", "docman_db")

# Global database client
client = None
db = None

def connect_to_mongo():
    """Create database connection"""
    global client, db
    client = MongoClient(MONGODB_URL)
    db = client[DATABASE_NAME]

def close_mongo_connection():
    """Close database connection"""
    global client
    if client:
        client.close()

def get_database():
    """Get database instance"""
    return db


