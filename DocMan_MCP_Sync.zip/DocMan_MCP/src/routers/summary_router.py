
from fastapi import APIRouter, HTTPException, Depends
from models import db_models, schemas
from services.summary_service import SummaryService
from bson import ObjectId
from config.db import get_database

router = APIRouter()

@router.post("/summary/document/{document_id}")
def generate_document_summary(document_id: str, db = Depends(get_database)):
    if not ObjectId.is_valid(document_id):
        raise HTTPException(status_code=400, detail="Invalid document ID")
    
    document_data = db.documents.find_one({"_id": ObjectId(document_id)})
    if document_data is None:
        raise HTTPException(status_code=404, detail="Document not found")
    document = schemas.Document(**document_data)
    
    summary_service = SummaryService()
    summary = summary_service.generate_summary(document.file_path)
    
    return {
        "document_id": str(document.id),
        "document_title": document.title,
        "summary": summary
    }

@router.post("/summary/project/{project_id}")
def generate_project_summary(project_id: str, db = Depends(get_database)):
    if not ObjectId.is_valid(project_id):
        raise HTTPException(status_code=400, detail="Invalid project ID")
    
    project_data = db.projects.find_one({"_id": ObjectId(project_id)})
    if project_data is None:
        raise HTTPException(status_code=404, detail="Project not found")
    project = schemas.Project(**project_data)
    
    documents_data = list(db.documents.find({"project_id": ObjectId(project_id)}))
    if not documents_data:
        raise HTTPException(status_code=404, detail="No documents found in this project")
    documents = [schemas.Document(**doc) for doc in documents_data]
    
    summary_service = SummaryService()
    project_summary = summary_service.generate_project_summary([doc.file_path for doc in documents])
    
    return {
        "project_id": str(project.id),
        "project_name": project.name,
        "document_count": len(documents),
        "summary": project_summary
    }

