from fastapi import APIRouter, HTTPException, UploadFile, File, Depends
from typing import List
from models import schemas, db_models
from bson import ObjectId
from config.db import get_database

router = APIRouter()

@router.post("/documents/", response_model=schemas.Document)
def create_document(document: schemas.DocumentCreate, db = Depends(get_database)):
    # Create a new document with a default owner_id (should be from authenticated user)
    doc_data = document.dict()
    doc_data["owner_id"] = ObjectId("507f1f77bcf86cd799439011")  # Default ObjectId, should be from auth
    if doc_data["project_id"]:
        doc_data["project_id"] = ObjectId(doc_data["project_id"])
    
    result = db.documents.insert_one(doc_data)
    new_doc = db.documents.find_one({"_id": result.inserted_id})
    return schemas.Document(**new_doc)

@router.get("/documents/", response_model=List[schemas.Document])
def read_documents(skip: int = 0, limit: int = 100, db = Depends(get_database)):
    documents = list(db.documents.find().skip(skip).limit(limit))
    return [schemas.Document(**doc) for doc in documents]

@router.get("/documents/{document_id}", response_model=schemas.Document)
def read_document(document_id: str, db = Depends(get_database)):
    if not ObjectId.is_valid(document_id):
        raise HTTPException(status_code=400, detail="Invalid document ID")
    
    document = db.documents.find_one({"_id": ObjectId(document_id)})
    if document is None:
        raise HTTPException(status_code=404, detail="Document not found")
    return schemas.Document(**document)

@router.post("/documents/upload/")
def upload_document(file: UploadFile = File(...), db = Depends(get_database)):
    file_location = f"src/uploads/{file.filename}"
    with open(file_location, "wb+") as file_object:
        file_object.write(file.file.read())
    
    doc_data = {
        "title": file.filename,
        "file_path": file_location,
        "owner_id": ObjectId("507f1f77bcf86cd799439011")  # Default ObjectId, should be from auth
    }
    result = db.documents.insert_one(doc_data)
    new_doc = db.documents.find_one({"_id": result.inserted_id})
    
    return {"info": f"file \'{file.filename}\' saved at \'{file_location}\'", "document": schemas.Document(**new_doc)}

@router.delete("/documents/{document_id}")
def delete_document(document_id: str, db = Depends(get_database)):
    if not ObjectId.is_valid(document_id):
        raise HTTPException(status_code=400, detail="Invalid document ID")
    
    result = db.documents.delete_one({"_id": ObjectId(document_id)})
    if result.deleted_count == 0:
        raise HTTPException(status_code=404, detail="Document not found")
    return {"message": "Document deleted successfully"}