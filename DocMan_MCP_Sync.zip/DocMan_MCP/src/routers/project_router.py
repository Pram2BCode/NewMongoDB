
from fastapi import APIRouter, HTTPException, Depends
from typing import List
from models import schemas, db_models
from bson import ObjectId
from config.db import get_database

router = APIRouter()

@router.post("/projects/", response_model=schemas.Project)
def create_project(project: schemas.ProjectCreate, db = Depends(get_database)):
    project_data = project.dict()
    project_data["owner_id"] = ObjectId("507f1f77bcf86cd799439011")  # Default ObjectId, should be from auth
    result = db.projects.insert_one(project_data)
    new_project = db.projects.find_one({"_id": result.inserted_id})
    return schemas.Project(**new_project)

@router.get("/projects/", response_model=List[schemas.Project])
def read_projects(skip: int = 0, limit: int = 100, db = Depends(get_database)):
    projects = list(db.projects.find().skip(skip).limit(limit))
    return [schemas.Project(**proj) for proj in projects]

@router.get("/projects/{project_id}", response_model=schemas.Project)
def read_project(project_id: str, db = Depends(get_database)):
    if not ObjectId.is_valid(project_id):
        raise HTTPException(status_code=400, detail="Invalid project ID")
    
    project = db.projects.find_one({"_id": ObjectId(project_id)})
    if project is None:
        raise HTTPException(status_code=404, detail="Project not found")
    return schemas.Project(**project)

@router.put("/projects/{project_id}", response_model=schemas.Project)
def update_project(project_id: str, project: schemas.ProjectCreate, db = Depends(get_database)):
    if not ObjectId.is_valid(project_id):
        raise HTTPException(status_code=400, detail="Invalid project ID")
    
    updated_project = db.projects.find_one_and_update(
        {"_id": ObjectId(project_id)},
        {"$set": project.dict(exclude_unset=True)},
        return_document=True
    )
    if updated_project is None:
        raise HTTPException(status_code=404, detail="Project not found")
    
    return schemas.Project(**updated_project)

@router.delete("/projects/{project_id}")
def delete_project(project_id: str, db = Depends(get_database)):
    if not ObjectId.is_valid(project_id):
        raise HTTPException(status_code=400, detail="Invalid project ID")
    
    result = db.projects.delete_one({"_id": ObjectId(project_id)})
    if result.deleted_count == 0:
        raise HTTPException(status_code=404, detail="Project not found")
    return {"message": "Project deleted successfully"}

