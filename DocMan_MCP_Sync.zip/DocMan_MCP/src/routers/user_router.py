
from fastapi import APIRouter, HTTPException, Depends
from typing import List
from models import schemas, db_models
from bson import ObjectId
from config.db import get_database

router = APIRouter()

@router.post("/users/", response_model=schemas.User)
def create_user(user: schemas.UserCreate, db = Depends(get_database)):
    # Check if user already exists
    existing_user = db.users.find_one({"email": user.email})
    if existing_user:
        raise HTTPException(status_code=400, detail="Email already registered")
    
    # Hash password (in production, use proper password hashing)
    hashed_password = user.password + "_hashed"  # Placeholder
    
    user_data = {
        "username": user.username,
        "email": user.email,
        "hashed_password": hashed_password
    }
    result = db.users.insert_one(user_data)
    new_user = db.users.find_one({"_id": result.inserted_id})
    return schemas.User(**new_user)

@router.get("/users/", response_model=List[schemas.User])
def read_users(skip: int = 0, limit: int = 100, db = Depends(get_database)):
    users = list(db.users.find().skip(skip).limit(limit))
    return [schemas.User(**user) for user in users]

@router.get("/users/{user_id}", response_model=schemas.User)
def read_user(user_id: str, db = Depends(get_database)):
    if not ObjectId.is_valid(user_id):
        raise HTTPException(status_code=400, detail="Invalid user ID")
    
    user = db.users.find_one({"_id": ObjectId(user_id)})
    if user is None:
        raise HTTPException(status_code=404, detail="User not found")
    return schemas.User(**user)

@router.delete("/users/{user_id}")
def delete_user(user_id: str, db = Depends(get_database)):
    if not ObjectId.is_valid(user_id):
        raise HTTPException(status_code=400, detail="Invalid user ID")
    
    result = db.users.delete_one({"_id": ObjectId(user_id)})
    if result.deleted_count == 0:
        raise HTTPException(status_code=404, detail="User not found")
    return {"message": "User deleted successfully"}

